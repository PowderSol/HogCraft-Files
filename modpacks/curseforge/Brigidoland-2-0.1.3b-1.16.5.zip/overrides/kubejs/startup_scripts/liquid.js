onEvent('fluid.registry', event => {    
    event.create('dark_matter_fluid')
         .textureThick(0x222224)
         .bucketColor(0x222224)
         .displayName('Dark Matter Fluid')
  })

onEvent('fluid.registry', event => {    
    event.create('polonium_liquid')
         .textureThick(0x00fa9a)
         .bucketColor(0x00fa9a)
         .displayName('Polonium Liquid')
  })