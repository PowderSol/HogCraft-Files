This directory is for adding YUNG's Better Mineshafts advanced options.
Options provided may vary by version.
This directory contains subdirectories for supported versions. The first time you run Better Mineshafts, a version subdirectory will be created if that version supports advanced options.
For example, the first time you use Better Mineshafts v2.0+ for Minecraft 1.12.2, the '1_12_2' subdirectory will be created in this folder.
If no subdirectory for your version is created, then that version probably does not support advanced options.